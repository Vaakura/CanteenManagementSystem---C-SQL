﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SQLite;


namespace CanteenManagentSystem
{
    public partial class FrmLogin : Form
    {
         string dbConnectionString = @"Data source = Database.db; version=3;"; 
        SQLiteConnection connect;
        //private OleDbConnection connection = new OleDbConnection();

        public FrmLogin()
        {
            InitializeComponent();
            


        }


        private void FrmLogin_Load(object sender, EventArgs e)
        {
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
               /* connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "select * from UserDetails where UserName='" + txtUserId.Text + "'and Password='" + txtPassword + "'";
                OleDbDataReader reader = command.ExecuteReader();*/
            SQLiteConnection sqlteCon = new SQLiteConnection(dbConnectionString);
            try
            {
                sqlteCon.Open();
                string qeury = "SELECT * FROM CLIENTS WHERE  LoginDetails ='" + txtUserId.Text + "' AND Password ='" + txtPassword + "'AND STATUS='login'";

                SQLiteCommand cmd = new SQLiteCommand(qeury, sqlteCon);
                SQLiteDataReader rd = cmd.ExecuteReader();
                int COUNT = 0;
                while (rd.Read())
                {
                    COUNT++;
                }
                if (COUNT == 1)
                {
                    MessageBox.Show("cellphone and password correct");
                    this.Hide();
                    FrmOrder order = new FrmOrder();
                    order.ShowDialog();

                }
                else
                {
                    MessageBox.Show("cellphone and password incorrect!");
                }

                sqlteCon.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        }

    }


    

