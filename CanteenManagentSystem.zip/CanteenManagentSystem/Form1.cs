﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SQLite;


namespace CanteenManagentSystem
{
    public partial class FrmRegister : Form
    {
        SQLiteConnection connect;


        public FrmRegister()
        {
            connect = new SQLiteConnection("Data Source = CanteenDatabase.sqlite; version=3;");
          
            InitializeComponent();


        }
        private void FrmRegister_Load(object sender, EventArgs e)
        {

        }
      
        
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void btnOrder_Click(object sender, EventArgs e)
        {

            try
            {
                connect.Open();
                string query = "insert into UserDetails(StudentNumber,StudentName,DateOfBirth,Address)values(" + "'" + txtStudentNumber.Text + "'," + "'" + txtStudentName.Text + "'," + "'" + txtDateOfBirth.Text + "'," + "'" + txtAddress.Text + "')";

                SQLiteCommand cmd = new SQLiteCommand(query, connect);
                cmd.ExecuteNonQuery();
                connect.Close();

                FrmLogin fl = new FrmLogin();
                this.Hide();
                fl.ShowDialog();
                

               

            }
            catch(Exception ex)
            {
                MessageBox.Show(""+ex);

              
                
            }


       }


        

        private void button1_Click(object sender, EventArgs e)
        {
            FrmLogin fl = new FrmLogin();
            this.Hide();
            fl.ShowDialog();

        }

        private void FrmRegister_Load(object sender, EventArgs e)
        {

        }

        private void FrmRegister_Load_1(object sender, EventArgs e)
        {

        }

      
    }
}
    

      


      
    

