﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CanteenManagentSystem
{
    class Calculation
    {

        public Calculation()
        {
            newCoffee = 0.0;
            newCoke = 0.0;
            newJuice = 0.0;
            newLatte = 0.0;
            newWine = 0.0;
            newBeer = 0.0;


            newMeat = 0.0;
            newRice = 0.0;
            newSpagetti = 0.0;
            newMacoroni = 0.0;
            newChicken = 0.0;
            newSalad = 0.0;
        }

        //overload constructor
        public Calculation(double Coffee, double Coke, double Juice, double Beer, double Latte, double Wine, double Rice, double Spagetti,double Meat, double Macoroni, double Chicken, double Salad)
            {
            //dinks
             newCoffee=Coffee;
             newCoke = Coke; 
             newJuice=Juice;
            newLatte=Latte;
            newWine=Wine;
            newBeer = Beer;
            //food
            newRice=Rice;
            newSpagetti=Spagetti;
            newMacoroni=Macoroni;
            newChicken=Chicken;
            newSalad=Salad;
            newMeat = Meat;

        }

        //Accessor function
        public double getCoffe()
        {
            return newCoffee;
        }
        public double getWine()
        {
            return newWine;
        }
        public double getBeer()
        {
            return newBeer;
        }
     

        public double getJuice()
        {
            return newJuice;
        }
        public double getCoke()
        {
            return newCoke;
        }
        public double getRice()
        {
            return newRice;
        }

        public double getSpagetti()
        {
            return newSpagetti;
        }
        public double getMacaroni()
        {
            return newMacoroni;
        }
        public double getChicken()
        {
            return newChicken;
        }
        public double getMeat()
        {
            return newMeat;
        }
     
     
        





        //varicble for coffe
       
        private double newCoffee;
        private double newCoke; 
        private double newJuice;
        private double newLatte;
        private double newWine;
        private double newBeer;



        private double newMeat;
        private double newRice;
        private double newSpagetti;
        private double newMacoroni;
        private double newChicken;
        private double newSalad;
    }
}
