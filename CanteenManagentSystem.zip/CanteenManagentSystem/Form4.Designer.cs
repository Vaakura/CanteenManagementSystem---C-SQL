﻿namespace CanteenManagentSystem
{
    partial class FrmOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmOrder));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCanteen = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkWine = new System.Windows.Forms.CheckBox();
            this.chkBeer = new System.Windows.Forms.CheckBox();
            this.chkJuice = new System.Windows.Forms.CheckBox();
            this.chkLatte = new System.Windows.Forms.CheckBox();
            this.chkCoke = new System.Windows.Forms.CheckBox();
            this.chkCoffe = new System.Windows.Forms.CheckBox();
            this.txtBeer = new System.Windows.Forms.TextBox();
            this.txtJuice = new System.Windows.Forms.TextBox();
            this.txtCoke = new System.Windows.Forms.TextBox();
            this.txtLatte = new System.Windows.Forms.TextBox();
            this.txtWine = new System.Windows.Forms.TextBox();
            this.txtCoffe = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.chkSalad = new System.Windows.Forms.CheckBox();
            this.chkRice = new System.Windows.Forms.CheckBox();
            this.chkSpagetti = new System.Windows.Forms.CheckBox();
            this.chkMacoroni = new System.Windows.Forms.CheckBox();
            this.chkChicken = new System.Windows.Forms.CheckBox();
            this.chkMeat = new System.Windows.Forms.CheckBox();
            this.txtMacoroni = new System.Windows.Forms.TextBox();
            this.txtSalad = new System.Windows.Forms.TextBox();
            this.txtRice = new System.Windows.Forms.TextBox();
            this.txtChicken = new System.Windows.Forms.TextBox();
            this.txtSpagetti = new System.Windows.Forms.TextBox();
            this.txtMeat = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtService = new System.Windows.Forms.TextBox();
            this.txtCOF = new System.Windows.Forms.TextBox();
            this.txtCOD = new System.Windows.Forms.TextBox();
            this.lblCostOfFood = new System.Windows.Forms.Label();
            this.lblServiceCharge = new System.Windows.Forms.Label();
            this.lblCostOfDrinks = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtSuBTotal = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.printToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.copyToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.pasteToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.helpToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.txtDisplay = new System.Windows.Forms.RichTextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnReceipt = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.lblTime);
            this.panel1.Controls.Add(this.lblDate);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblCanteen);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1160, 162);
            this.panel1.TabIndex = 0;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(72, 136);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(35, 13);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "label3";
            this.lblTime.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(968, 136);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(35, 13);
            this.lblDate.TabIndex = 1;
            this.lblDate.Text = "label2";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("Webdings", 60.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(14, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(360, 88);
            this.label1.TabIndex = 0;
            this.label1.Text = "";
            // 
            // lblCanteen
            // 
            this.lblCanteen.AutoSize = true;
            this.lblCanteen.Font = new System.Drawing.Font("Microsoft Sans Serif", 30.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCanteen.Location = new System.Drawing.Point(409, 42);
            this.lblCanteen.Name = "lblCanteen";
            this.lblCanteen.Size = new System.Drawing.Size(348, 47);
            this.lblCanteen.TabIndex = 0;
            this.lblCanteen.Text = "CANTEEN MENU";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.chkWine);
            this.panel2.Controls.Add(this.chkBeer);
            this.panel2.Controls.Add(this.chkJuice);
            this.panel2.Controls.Add(this.chkLatte);
            this.panel2.Controls.Add(this.chkCoke);
            this.panel2.Controls.Add(this.chkCoffe);
            this.panel2.Controls.Add(this.txtBeer);
            this.panel2.Controls.Add(this.txtJuice);
            this.panel2.Controls.Add(this.txtCoke);
            this.panel2.Controls.Add(this.txtLatte);
            this.panel2.Controls.Add(this.txtWine);
            this.panel2.Controls.Add(this.txtCoffe);
            this.panel2.Location = new System.Drawing.Point(12, 189);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(395, 273);
            this.panel2.TabIndex = 1;
            // 
            // chkWine
            // 
            this.chkWine.AutoSize = true;
            this.chkWine.Location = new System.Drawing.Point(188, 77);
            this.chkWine.Name = "chkWine";
            this.chkWine.Size = new System.Drawing.Size(51, 17);
            this.chkWine.TabIndex = 17;
            this.chkWine.Text = "Wine";
            this.chkWine.UseVisualStyleBackColor = true;
            // 
            // chkBeer
            // 
            this.chkBeer.AutoSize = true;
            this.chkBeer.Location = new System.Drawing.Point(188, 128);
            this.chkBeer.Name = "chkBeer";
            this.chkBeer.Size = new System.Drawing.Size(48, 17);
            this.chkBeer.TabIndex = 16;
            this.chkBeer.Text = "Beer";
            this.chkBeer.UseVisualStyleBackColor = true;
            // 
            // chkJuice
            // 
            this.chkJuice.AutoSize = true;
            this.chkJuice.Location = new System.Drawing.Point(3, 131);
            this.chkJuice.Name = "chkJuice";
            this.chkJuice.Size = new System.Drawing.Size(51, 17);
            this.chkJuice.TabIndex = 15;
            this.chkJuice.Text = "Juice";
            this.chkJuice.UseVisualStyleBackColor = true;
            // 
            // chkLatte
            // 
            this.chkLatte.AutoSize = true;
            this.chkLatte.Location = new System.Drawing.Point(188, 31);
            this.chkLatte.Name = "chkLatte";
            this.chkLatte.Size = new System.Drawing.Size(50, 17);
            this.chkLatte.TabIndex = 14;
            this.chkLatte.Text = "Latte";
            this.chkLatte.UseVisualStyleBackColor = true;
            // 
            // chkCoke
            // 
            this.chkCoke.AutoSize = true;
            this.chkCoke.Location = new System.Drawing.Point(0, 77);
            this.chkCoke.Name = "chkCoke";
            this.chkCoke.Size = new System.Drawing.Size(51, 17);
            this.chkCoke.TabIndex = 12;
            this.chkCoke.Text = "Coke";
            this.chkCoke.UseVisualStyleBackColor = true;
            this.chkCoke.CheckedChanged += new System.EventHandler(this.chkCoke_CheckedChanged_1);
            // 
            // chkCoffe
            // 
            this.chkCoffe.AutoSize = true;
            this.chkCoffe.Location = new System.Drawing.Point(3, 31);
            this.chkCoffe.Name = "chkCoffe";
            this.chkCoffe.Size = new System.Drawing.Size(57, 17);
            this.chkCoffe.TabIndex = 11;
            this.chkCoffe.Text = "Coffee";
            this.chkCoffe.UseVisualStyleBackColor = true;
            this.chkCoffe.CheckedChanged += new System.EventHandler(this.chkCoffe_CheckedChanged);
            // 
            // txtBeer
            // 
            this.txtBeer.Location = new System.Drawing.Point(274, 126);
            this.txtBeer.Name = "txtBeer";
            this.txtBeer.Size = new System.Drawing.Size(100, 20);
            this.txtBeer.TabIndex = 10;
            this.txtBeer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtJuice
            // 
            this.txtJuice.Location = new System.Drawing.Point(86, 126);
            this.txtJuice.Name = "txtJuice";
            this.txtJuice.Size = new System.Drawing.Size(100, 20);
            this.txtJuice.TabIndex = 9;
            this.txtJuice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCoke
            // 
            this.txtCoke.Location = new System.Drawing.Point(86, 75);
            this.txtCoke.Name = "txtCoke";
            this.txtCoke.Size = new System.Drawing.Size(100, 20);
            this.txtCoke.TabIndex = 8;
            this.txtCoke.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCoke.TextChanged += new System.EventHandler(this.txtCoke_TextChanged_1);
            // 
            // txtLatte
            // 
            this.txtLatte.Location = new System.Drawing.Point(274, 25);
            this.txtLatte.Name = "txtLatte";
            this.txtLatte.Size = new System.Drawing.Size(100, 20);
            this.txtLatte.TabIndex = 7;
            this.txtLatte.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtWine
            // 
            this.txtWine.Location = new System.Drawing.Point(274, 72);
            this.txtWine.Name = "txtWine";
            this.txtWine.Size = new System.Drawing.Size(100, 20);
            this.txtWine.TabIndex = 6;
            this.txtWine.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCoffe
            // 
            this.txtCoffe.Location = new System.Drawing.Point(86, 28);
            this.txtCoffe.Name = "txtCoffe";
            this.txtCoffe.Size = new System.Drawing.Size(100, 20);
            this.txtCoffe.TabIndex = 5;
            this.txtCoffe.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCoffe.TextChanged += new System.EventHandler(this.txtCoffe_TextChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel3.Controls.Add(this.chkSalad);
            this.panel3.Controls.Add(this.chkRice);
            this.panel3.Controls.Add(this.chkSpagetti);
            this.panel3.Controls.Add(this.chkMacoroni);
            this.panel3.Controls.Add(this.chkChicken);
            this.panel3.Controls.Add(this.chkMeat);
            this.panel3.Controls.Add(this.txtMacoroni);
            this.panel3.Controls.Add(this.txtSalad);
            this.panel3.Controls.Add(this.txtRice);
            this.panel3.Controls.Add(this.txtChicken);
            this.panel3.Controls.Add(this.txtSpagetti);
            this.panel3.Controls.Add(this.txtMeat);
            this.panel3.Location = new System.Drawing.Point(413, 189);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(345, 273);
            this.panel3.TabIndex = 2;
            // 
            // chkSalad
            // 
            this.chkSalad.AutoSize = true;
            this.chkSalad.Location = new System.Drawing.Point(182, 128);
            this.chkSalad.Name = "chkSalad";
            this.chkSalad.Size = new System.Drawing.Size(53, 17);
            this.chkSalad.TabIndex = 22;
            this.chkSalad.Text = "Salad";
            this.chkSalad.UseVisualStyleBackColor = true;
            // 
            // chkRice
            // 
            this.chkRice.AutoSize = true;
            this.chkRice.Location = new System.Drawing.Point(3, 29);
            this.chkRice.Name = "chkRice";
            this.chkRice.Size = new System.Drawing.Size(48, 17);
            this.chkRice.TabIndex = 21;
            this.chkRice.Text = "Rice";
            this.chkRice.UseVisualStyleBackColor = true;
            // 
            // chkSpagetti
            // 
            this.chkSpagetti.AutoSize = true;
            this.chkSpagetti.Location = new System.Drawing.Point(3, 77);
            this.chkSpagetti.Name = "chkSpagetti";
            this.chkSpagetti.Size = new System.Drawing.Size(65, 17);
            this.chkSpagetti.TabIndex = 20;
            this.chkSpagetti.Text = "Spagetti";
            this.chkSpagetti.UseVisualStyleBackColor = true;
            // 
            // chkMacoroni
            // 
            this.chkMacoroni.AutoSize = true;
            this.chkMacoroni.Location = new System.Drawing.Point(3, 126);
            this.chkMacoroni.Name = "chkMacoroni";
            this.chkMacoroni.Size = new System.Drawing.Size(70, 17);
            this.chkMacoroni.TabIndex = 19;
            this.chkMacoroni.Text = "Macoroni";
            this.chkMacoroni.UseVisualStyleBackColor = true;
            // 
            // chkChicken
            // 
            this.chkChicken.AutoSize = true;
            this.chkChicken.Location = new System.Drawing.Point(182, 29);
            this.chkChicken.Name = "chkChicken";
            this.chkChicken.Size = new System.Drawing.Size(65, 17);
            this.chkChicken.TabIndex = 18;
            this.chkChicken.Text = "Chicken";
            this.chkChicken.UseVisualStyleBackColor = true;
            // 
            // chkMeat
            // 
            this.chkMeat.AutoSize = true;
            this.chkMeat.Location = new System.Drawing.Point(182, 78);
            this.chkMeat.Name = "chkMeat";
            this.chkMeat.Size = new System.Drawing.Size(50, 17);
            this.chkMeat.TabIndex = 17;
            this.chkMeat.Text = "Meat";
            this.chkMeat.UseVisualStyleBackColor = true;
            // 
            // txtMacoroni
            // 
            this.txtMacoroni.Location = new System.Drawing.Point(76, 126);
            this.txtMacoroni.Name = "txtMacoroni";
            this.txtMacoroni.Size = new System.Drawing.Size(100, 20);
            this.txtMacoroni.TabIndex = 11;
            this.txtMacoroni.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSalad
            // 
            this.txtSalad.Location = new System.Drawing.Point(242, 123);
            this.txtSalad.Name = "txtSalad";
            this.txtSalad.Size = new System.Drawing.Size(100, 20);
            this.txtSalad.TabIndex = 10;
            this.txtSalad.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtRice
            // 
            this.txtRice.Location = new System.Drawing.Point(76, 27);
            this.txtRice.Name = "txtRice";
            this.txtRice.Size = new System.Drawing.Size(100, 20);
            this.txtRice.TabIndex = 9;
            this.txtRice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtChicken
            // 
            this.txtChicken.Location = new System.Drawing.Point(242, 25);
            this.txtChicken.Name = "txtChicken";
            this.txtChicken.Size = new System.Drawing.Size(100, 20);
            this.txtChicken.TabIndex = 8;
            this.txtChicken.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSpagetti
            // 
            this.txtSpagetti.Location = new System.Drawing.Point(76, 72);
            this.txtSpagetti.Name = "txtSpagetti";
            this.txtSpagetti.Size = new System.Drawing.Size(100, 20);
            this.txtSpagetti.TabIndex = 7;
            this.txtSpagetti.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMeat
            // 
            this.txtMeat.Location = new System.Drawing.Point(242, 75);
            this.txtMeat.Name = "txtMeat";
            this.txtMeat.Size = new System.Drawing.Size(100, 20);
            this.txtMeat.TabIndex = 6;
            this.txtMeat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel4.Controls.Add(this.txtService);
            this.panel4.Controls.Add(this.txtCOF);
            this.panel4.Controls.Add(this.txtCOD);
            this.panel4.Controls.Add(this.lblCostOfFood);
            this.panel4.Controls.Add(this.lblServiceCharge);
            this.panel4.Controls.Add(this.lblCostOfDrinks);
            this.panel4.Location = new System.Drawing.Point(12, 468);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(395, 229);
            this.panel4.TabIndex = 3;
            // 
            // txtService
            // 
            this.txtService.Location = new System.Drawing.Point(195, 129);
            this.txtService.Name = "txtService";
            this.txtService.Size = new System.Drawing.Size(100, 20);
            this.txtService.TabIndex = 5;
            // 
            // txtCOF
            // 
            this.txtCOF.Location = new System.Drawing.Point(195, 87);
            this.txtCOF.Name = "txtCOF";
            this.txtCOF.Size = new System.Drawing.Size(100, 20);
            this.txtCOF.TabIndex = 4;
            // 
            // txtCOD
            // 
            this.txtCOD.Location = new System.Drawing.Point(195, 40);
            this.txtCOD.Name = "txtCOD";
            this.txtCOD.Size = new System.Drawing.Size(100, 20);
            this.txtCOD.TabIndex = 3;
            // 
            // lblCostOfFood
            // 
            this.lblCostOfFood.AutoSize = true;
            this.lblCostOfFood.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCostOfFood.Location = new System.Drawing.Point(17, 87);
            this.lblCostOfFood.Name = "lblCostOfFood";
            this.lblCostOfFood.Size = new System.Drawing.Size(64, 13);
            this.lblCostOfFood.TabIndex = 2;
            this.lblCostOfFood.Text = "Cost of food";
            // 
            // lblServiceCharge
            // 
            this.lblServiceCharge.AutoSize = true;
            this.lblServiceCharge.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblServiceCharge.Location = new System.Drawing.Point(17, 129);
            this.lblServiceCharge.Name = "lblServiceCharge";
            this.lblServiceCharge.Size = new System.Drawing.Size(80, 13);
            this.lblServiceCharge.TabIndex = 1;
            this.lblServiceCharge.Text = "Service Charge";
            // 
            // lblCostOfDrinks
            // 
            this.lblCostOfDrinks.AutoSize = true;
            this.lblCostOfDrinks.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCostOfDrinks.Location = new System.Drawing.Point(17, 43);
            this.lblCostOfDrinks.Name = "lblCostOfDrinks";
            this.lblCostOfDrinks.Size = new System.Drawing.Size(73, 13);
            this.lblCostOfDrinks.TabIndex = 0;
            this.lblCostOfDrinks.Text = "Cost of Drinks";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel5.Controls.Add(this.txtTax);
            this.panel5.Controls.Add(this.txtTotal);
            this.panel5.Controls.Add(this.txtSuBTotal);
            this.panel5.Controls.Add(this.lblTotal);
            this.panel5.Controls.Add(this.lblSubTotal);
            this.panel5.Controls.Add(this.lblTax);
            this.panel5.Location = new System.Drawing.Point(413, 468);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(345, 229);
            this.panel5.TabIndex = 4;
            // 
            // txtTax
            // 
            this.txtTax.Location = new System.Drawing.Point(192, 27);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(100, 20);
            this.txtTax.TabIndex = 6;
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(192, 113);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.TabIndex = 5;
            // 
            // txtSuBTotal
            // 
            this.txtSuBTotal.Location = new System.Drawing.Point(192, 70);
            this.txtSuBTotal.Name = "txtSuBTotal";
            this.txtSuBTotal.Size = new System.Drawing.Size(100, 20);
            this.txtSuBTotal.TabIndex = 4;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotal.Location = new System.Drawing.Point(31, 120);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(31, 13);
            this.lblTotal.TabIndex = 3;
            this.lblTotal.Text = "Total";
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.AutoSize = true;
            this.lblSubTotal.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSubTotal.Location = new System.Drawing.Point(31, 77);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(53, 13);
            this.lblSubTotal.TabIndex = 2;
            this.lblSubTotal.Text = "Sub Total";
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Location = new System.Drawing.Point(31, 34);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(25, 13);
            this.lblTax.TabIndex = 1;
            this.lblTax.Text = "Tax";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel6.Controls.Add(this.toolStrip1);
            this.panel6.Controls.Add(this.txtDisplay);
            this.panel6.Location = new System.Drawing.Point(764, 189);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(408, 340);
            this.panel6.TabIndex = 5;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripButton,
            this.openToolStripButton,
            this.saveToolStripButton,
            this.printToolStripButton,
            this.toolStripSeparator,
            this.cutToolStripButton,
            this.copyToolStripButton,
            this.pasteToolStripButton,
            this.toolStripSeparator1,
            this.helpToolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(408, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // newToolStripButton
            // 
            this.newToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripButton.Image")));
            this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripButton.Name = "newToolStripButton";
            this.newToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.newToolStripButton.Text = "&New";
            // 
            // openToolStripButton
            // 
            this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripButton.Image")));
            this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripButton.Name = "openToolStripButton";
            this.openToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.openToolStripButton.Text = "&Open";
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripButton.Image")));
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.saveToolStripButton.Text = "&Save";
            // 
            // printToolStripButton
            // 
            this.printToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.printToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripButton.Image")));
            this.printToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripButton.Name = "printToolStripButton";
            this.printToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.printToolStripButton.Text = "&Print";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // cutToolStripButton
            // 
            this.cutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cutToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripButton.Image")));
            this.cutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutToolStripButton.Name = "cutToolStripButton";
            this.cutToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.cutToolStripButton.Text = "C&ut";
            // 
            // copyToolStripButton
            // 
            this.copyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.copyToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripButton.Image")));
            this.copyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyToolStripButton.Name = "copyToolStripButton";
            this.copyToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.copyToolStripButton.Text = "&Copy";
            // 
            // pasteToolStripButton
            // 
            this.pasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pasteToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripButton.Image")));
            this.pasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripButton.Name = "pasteToolStripButton";
            this.pasteToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.pasteToolStripButton.Text = "&Paste";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // helpToolStripButton
            // 
            this.helpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.helpToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("helpToolStripButton.Image")));
            this.helpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.helpToolStripButton.Name = "helpToolStripButton";
            this.helpToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.helpToolStripButton.Text = "He&lp";
            // 
            // txtDisplay
            // 
            this.txtDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDisplay.Location = new System.Drawing.Point(23, 27);
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new System.Drawing.Size(368, 292);
            this.txtDisplay.TabIndex = 0;
            this.txtDisplay.Text = "";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel7.Controls.Add(this.btnReceipt);
            this.panel7.Controls.Add(this.btnReset);
            this.panel7.Controls.Add(this.btnExit);
            this.panel7.Controls.Add(this.btnTotal);
            this.panel7.Location = new System.Drawing.Point(764, 535);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(408, 162);
            this.panel7.TabIndex = 6;
            // 
            // btnReceipt
            // 
            this.btnReceipt.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnReceipt.Location = new System.Drawing.Point(109, 47);
            this.btnReceipt.Name = "btnReceipt";
            this.btnReceipt.Size = new System.Drawing.Size(75, 23);
            this.btnReceipt.TabIndex = 3;
            this.btnReceipt.Text = "Reciept";
            this.btnReceipt.UseVisualStyleBackColor = true;
            this.btnReceipt.Click += new System.EventHandler(this.btnReceipt_Click_1);
            // 
            // btnReset
            // 
            this.btnReset.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnReset.Location = new System.Drawing.Point(229, 47);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnExit.Location = new System.Drawing.Point(330, 47);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // btnTotal
            // 
            this.btnTotal.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnTotal.Location = new System.Drawing.Point(3, 47);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(75, 23);
            this.btnTotal.TabIndex = 0;
            this.btnTotal.Text = "Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.btnTotal_Click_1);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // FrmOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 711);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Name = "FrmOrder";
            this.Text = "Order";
            this.Load += new System.EventHandler(this.FrmOrder_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCanteen;
        private System.Windows.Forms.TextBox txtService;
        private System.Windows.Forms.TextBox txtCOF;
        private System.Windows.Forms.TextBox txtCOD;
        private System.Windows.Forms.Label lblCostOfFood;
        private System.Windows.Forms.Label lblServiceCharge;
        private System.Windows.Forms.Label lblCostOfDrinks;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtSuBTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.TextBox txtBeer;
        private System.Windows.Forms.TextBox txtJuice;
        private System.Windows.Forms.TextBox txtCoke;
        private System.Windows.Forms.TextBox txtLatte;
        private System.Windows.Forms.TextBox txtWine;
        private System.Windows.Forms.TextBox txtCoffe;
        private System.Windows.Forms.TextBox txtMacoroni;
        private System.Windows.Forms.TextBox txtSalad;
        private System.Windows.Forms.TextBox txtRice;
        private System.Windows.Forms.TextBox txtChicken;
        private System.Windows.Forms.TextBox txtSpagetti;
        private System.Windows.Forms.TextBox txtMeat;
        private System.Windows.Forms.RichTextBox txtDisplay;
        private System.Windows.Forms.Button btnReceipt;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.CheckBox chkWine;
        private System.Windows.Forms.CheckBox chkBeer;
        private System.Windows.Forms.CheckBox chkJuice;
        private System.Windows.Forms.CheckBox chkLatte;
        private System.Windows.Forms.CheckBox chkCoke;
        private System.Windows.Forms.CheckBox chkCoffe;
        private System.Windows.Forms.CheckBox chkSalad;
        private System.Windows.Forms.CheckBox chkRice;
        private System.Windows.Forms.CheckBox chkSpagetti;
        private System.Windows.Forms.CheckBox chkMacoroni;
        private System.Windows.Forms.CheckBox chkChicken;
        private System.Windows.Forms.CheckBox chkMeat;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton newToolStripButton;
        private System.Windows.Forms.ToolStripButton openToolStripButton;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.ToolStripButton printToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton cutToolStripButton;
        private System.Windows.Forms.ToolStripButton copyToolStripButton;
        private System.Windows.Forms.ToolStripButton pasteToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton helpToolStripButton;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lblTime;
    }
}