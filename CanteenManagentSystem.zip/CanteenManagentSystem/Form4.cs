﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CanteenManagentSystem
{
    public partial class FrmOrder : Form
    {
        public FrmOrder()
        {
            InitializeComponent();
        }

        private void FrmOrder_Load(object sender, EventArgs e)
        {

            lblDate.Text = DateTime.Now.ToLongDateString();
           
            timer2.Start();


            txtCoke.Text = "0";
            txtBeer.Text = "0";
            txtJuice.Text = "0";
            txtCoffe.Text = "0";
            txtWine.Text = "0";
            txtLatte.Text = "0";
           txtMacoroni.Text = "0";
            txtMeat.Text = "0";
            txtRice.Text = "0";
            txtSalad.Text = "0";
            txtSpagetti.Text = "0";
            txtChicken.Text = "0";
           txtCOD.Text = "0";
            txtCOF.Text = "0";
            txtSuBTotal.Text = "0";
            txtTax.Text = "0";
            txtService.Text="1.75";
            txtTotal.Text = "0";

           txtBeer.Enabled = false;
            txtJuice.Enabled = false;
            txtCoffe.Enabled = false;
            txtWine.Enabled = false;
            txtLatte.Enabled = false;
            txtMacoroni.Enabled = false;
            txtMeat.Enabled = false;
            txtRice.Enabled = false;
            txtSalad.Enabled = false;
            txtSpagetti.Enabled = false;
            txtChicken.Enabled = false;
            txtCoke.Enabled = false;

            chkBeer.Checked = false;
            chkChicken.Checked = false;
            chkCoffe.Checked = false;
            chkCoke.Checked = false;
            chkJuice.Checked = false;
            chkLatte.Checked = false;
            chkMacoroni.Checked = false;
            chkMeat.Checked = false;
            chkRice.Checked = false;
            chkSalad.Checked = false;
            chkSpagetti.Checked = false;
            chkWine.Checked = false; 





        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtBeer.Text = "0";
            txtJuice.Text = "0";
            txtCoffe.Text = "0";
            txtWine.Text = "0";
            txtLatte.Text = "0";
            txtCoke.Text = "0";
            
            txtMacoroni.Text = "0";
            txtMeat.Text = "0";
            txtRice.Text = "0";
            txtSalad.Text = "0";
            txtSpagetti.Text = "0";
            txtChicken.Text = "0";
            txtService.Text = "1.75";
            txtCOD.Text = "0";
            txtCOF.Text = "0";
            
           
            txtSuBTotal.Text = "0";
            txtTax.Text = "0";
            txtService.Text="1.75";
            txtTotal.Text = "0";
            



        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtCoffe_TextChanged(object sender, EventArgs e)
        {

            txtCoffe.Text = "";
            txtCoffe.Focus();
        }

        private void chkCoffe_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCoffe.Checked == true)
            {
                txtCoffe.Enabled = true;
            }

            if (chkCoffe.Checked == false)
            {
                txtCoffe.Enabled = false;
                txtCoffe.Text = "0";
            }
        }
    
        
        private void txtJuice_TextChanged(object sender, EventArgs e)
        {
            txtJuice.Text="";
            txtJuice.Focus();

        }
    

        private void chkCoke_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCoke.Checked == true)
            {
                txtCoke.Enabled = true;
            }

            if (chkCoke.Checked == false)
            {
                txtCoke.Enabled = false;
                txtCoke.Text = "0";

            }
        }

        private void chkJuice_CheckedChanged(object sender, EventArgs e)
        {
            if (chkJuice.Checked == true)
            {
                txtJuice.Enabled = true;
            }

            if (chkJuice.Checked == false)
            {
                txtJuice.Enabled = false;
                txtJuice.Text = "0";

            }
        }

        private void txtCoke_TextChanged(object sender, EventArgs e)
        {

            txtCoke.Text = "";
            txtCoke.Focus();

        }

        private void txtLatte_TextChanged(object sender, EventArgs e)
        {

            txtLatte.Text = "";
            txtLatte.Focus();


        }

        private void txtWine_TextChanged(object sender, EventArgs e)
        {

            txtWine.Text = "";
            txtWine.Focus();

        }

        private void txtBeer_TextChanged(object sender, EventArgs e)
        {

            txtBeer.Text = "";
            txtBeer.Focus();

        }

        private void chkLatte_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLatte.Checked == true)
            {
                txtLatte.Enabled = true;
            }

            if (chkLatte.Checked == false)
            {
                txtLatte.Enabled = false;
                txtLatte.Text = "0";


            }
        }

        private void chkWine_CheckedChanged(object sender, EventArgs e)
        {
            if (chkWine.Checked == true)
            {
                txtWine.Enabled = true;
            }

            if (chkWine.Checked == false)
            {
                txtWine.Enabled = false;
                txtWine.Text = "0";


            }
        }

        private void chkBeer_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBeer.Checked == true)
            {
                txtBeer.Enabled = true;
            }

            if (chkBeer.Checked == false)
            {
                txtBeer.Enabled = false;
                txtBeer.Text = "0";


            }
        }

        private void txtRice_TextChanged(object sender, EventArgs e)
        {
            txtRice.Enabled = false;
            txtRice.Text = "0";

        }

        private void txtSpagetti_TextChanged(object sender, EventArgs e)
        {
            txtSpagetti.Enabled = false;
            txtSpagetti.Text = "0";

        }

        private void txtMacoroni_TextChanged(object sender, EventArgs e)
        {
            txtMacoroni.Enabled = false;
            txtMacoroni.Text = "0";
        }

        private void txtChicken_TextChanged(object sender, EventArgs e)
        {
            txtChicken.Enabled = false;
            txtChicken.Text = "0";

        }

        private void txtSalad_TextChanged(object sender, EventArgs e)
        {
            txtSalad.Enabled = false;
            txtSalad.Text = "0";

        }

        private void txtMeat_TextChanged(object sender, EventArgs e)
        {
            txtMeat.Enabled = false;
            txtMeat.Text = "0";

        }

        private void chkRice_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRice.Checked == true)
            {
                txtRice.Enabled = true;
            }

            if (chkRice.Checked == false)
            {
                txtRice.Enabled = false;
                txtRice.Text = "0";



            }
        }

        private void chkSpagetti_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSpagetti.Checked == true)
            {
                txtSpagetti.Enabled = true;
            }

            if (chkSpagetti.Checked == false)
            {
                txtSpagetti.Enabled = false;
                txtSpagetti.Text = "0";


            }
        }

        private void chkMacoroni_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMacoroni.Checked == true)
            {
                txtMacoroni.Enabled = true;
            }

            if (chkMacoroni.Checked == false)
            {
                txtMacoroni.Enabled = false;
                txtMacoroni.Text = "0";



            }
        }


        private void chkChicken_CheckedChanged(object sender, EventArgs e)
        {
            if (chkChicken.Checked == true)
            {
                txtChicken.Enabled = true;
            }

            if (chkChicken.Checked == false)
            {
                txtChicken.Enabled = false;
                txtChicken.Text = "0";



            }
        }

        private void chkMeat_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMeat.Checked == true)
            {
                txtMeat.Enabled = true;
            }

            if (chkMeat.Checked == false)
            {
                txtMeat.Enabled = false;
                txtMeat.Text = "0";


            }
        }

        private void chkSalad_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSalad.Checked == true)
            {
                txtSalad.Enabled = true;
            }

            if (chkSalad.Checked == false)
            {
                txtSalad.Enabled = false;
                txtSalad.Text = "0";



            }
        }

         private void lblTime_Click(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToLongTimeString();
        }
        

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(txtDisplay.Text, new Font("Arial", 14, FontStyle.Regular), Brushes.Black, 120, 120);


        }

        private void printToolStripButton_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();

        }

        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();

        }

        private void cutToolStripButton_Click(object sender, EventArgs e)
        {
            txtDisplay.Cut();
        }

        private void copyToolStripButton_Click(object sender, EventArgs e)
        {
            txtDisplay.Copy();

        }

        private void pasteToolStripButton_Click(object sender, EventArgs e)
        {
            txtDisplay.Paste();

        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();

            openFile.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";


            if (openFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                txtDisplay.LoadFile(openFile.FileName, RichTextBoxStreamType.PlainText);
        }

        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();

            saveFile.FileName = "Notepad Text";
            saveFile.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";


            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(saveFile.FileName))
                    sw.WriteLine(txtDisplay.Text);

            }

        }

        private void btnReceipt_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();

            txtDisplay.AppendText(Environment.NewLine);
            txtDisplay.AppendText("........................................................." + Environment.NewLine);
            txtDisplay.AppendText("\t\t\t" + "..................NUST CANTEEN................" + Environment.NewLine);
            txtDisplay.AppendText("........................................................." + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("COFFE \t\t\t" + txtCoffe.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("Coke \t\t\t" + txtCoke.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("juice \t\t\t" + txtJuice.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("Latte \t\t\t" + txtLatte.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("Wine \t\t\t" + txtWine.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("BEER \t\t\t" + txtBeer.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("RICE \t\t\t" + txtRice.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("SPAGETTI \t\t\t" + txtSpagetti.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("MACORONI \t\t\t" + txtMacoroni.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("CHICKEN \t\t\t" + txtChicken.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("MEAT \t\t\t" + txtMeat.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("SALAD \t\t\t" + txtSalad.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("............................................................"+ Environment.NewLine + Environment.NewLine); 
            txtDisplay.AppendText("TAX \t\t\t" + lblTax.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("SERVICE CHARGE \t\t\t" + txtService.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("............................................................" + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("SUBTOTAL \t\t\t" + lblSubTotal.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText(" TOTAL \t\t\t" + lblTotal + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("ORDER WILL BE READY IN 90 MINUTES..........................." + txtCoffe.Text + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("............................................................" + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText("PRINT RECIEPT FOR PROOF!! .................................." + Environment.NewLine + Environment.NewLine);
            txtDisplay.AppendText(lblTime.Text +"\t\t\t" + lblDate.Text);
        }

        private void btnTotal_Click(object sender, EventArgs e)
        {

            double tax;
            tax = 0.25;
            double  DCoffe,DCoke,DJuice,DLatte,DWine,DBeer;
            double FRice,FSpagetti,FMacoroni,FChicken,FMeat,FSalad;

            //drinks

            DCoffe=5.00;
            DCoke=6.00;
            DJuice=10.00;
            DLatte=25.50;
            DWine=45.00;
            DBeer = 15.00;


 


            double Coffee = Convert.ToDouble(txtCoffe.Text) ;
           double Coke = Convert.ToDouble(txtCoke.Text);
            double Juice = Convert.ToDouble(txtJuice.Text) ;
            double Latte = Convert.ToDouble(txtLatte.Text);
            double Wine = Convert.ToDouble(txtWine.Text) ;
             double Beer = Convert.ToDouble(txtBeer.Text);

            //food

            FRice = 25.00;
            FSpagetti = 30.00;
            FMacoroni = 35.00;
            FChicken = 10.00;
            FMeat = 20.00;
            FSalad = 25.00;




            double Rice= Convert.ToDouble(txtRice.Text) ;
            double Spagetti = Convert.ToDouble(txtSpagetti.Text) ;
            double Macoroni = Convert.ToDouble(txtMacoroni.Text) ;
            double Chicken = Convert.ToDouble(txtChicken.Text) ;
            double Salad = Convert.ToDouble(txtSalad.Text);
            double Meat = Convert.ToDouble(txtMeat.Text);


            Calculation deliver_cost = new Calculation( Coffee, Coke,Juice, Beer, Latte, Wine,  Rice, Meat, Spagetti,  Macoroni,  Chicken,  Salad);

            double costOfDrinks = (Coffee * DCoffe) + (Coke * DCoke) + (Juice * DJuice) + (Beer * DBeer) + (Latte * DLatte) + (Wine + DWine);
            txtCOD.Text = Convert.ToString(costOfDrinks);

            double costOfFood =(Rice *FRice) +  (Spagetti*FSpagetti) +(Macoroni+FMacoroni) +(Chicken+FChicken) +(Salad+FSalad)+(Meat +FMeat);
            txtCOF.Text = Convert.ToString(costOfFood);

            double service = Convert.ToDouble(txtService.Text);

            txtSuBTotal.Text = Convert.ToString(costOfDrinks + costOfFood + service);
            txtTax.Text = Convert.ToString(((costOfDrinks + costOfFood + service)*tax)/100);
            double Itax = Convert.ToDouble(txtTax.Text);
            txtTotal.Text = Convert.ToString(costOfDrinks + costOfFood + Itax + service);


        }


        private void label3_Click(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToLongTimeString();

        }

        private void txtCoke_TextChanged_1(object sender, EventArgs e)
        {

            txtCoke.Text = "";
            txtCoke.Focus();

        }

        private void chkCoke_CheckedChanged_1(object sender, EventArgs e)
        {if (chkCoke.Checked == true)
            {
                txtCoke.Enabled = true;
            }

            if (chkCoke.Checked == false)
            {
                txtCoke.Enabled = false;
                txtCoke.Text = "0";

            }
        }

        private void btnTotal_Click_1(object sender, EventArgs e)
        {

        }

        private void btnReceipt_Click_1(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {

        }

        }

   
    
        
        }
    

